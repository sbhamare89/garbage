$("#settings").remove();
$("#business_details").remove();
$("#help").remove();
$("#support").remove();
$("#logout").remove();
