$(".account-logo").remove();
